(function enableRightClick() {
    "use strict";

    // Add style to allow text selection
    const style = document.createElement("style");
    style.textContent = `
        * {
            -webkit-user-select: text !important;
            -moz-user-select: text !important;
            -ms-user-select: text !important;
            user-select: text !important;
            pointer-events: auto !important;
        }
        [style*="user-select: none"] {
            -webkit-user-select: text !important;
            -moz-user-select: text !important;
            -ms-user-select: text !important;
            user-select: text !important;
        }
    `;
    
    // Safely append style
    if (document.head) {
        document.head.appendChild(style);
    } else {
        document.addEventListener('DOMContentLoaded', () => {
            document.head.appendChild(style);
        });
    }

    // Remove common event restrictions
    const eventsToClear = [
        "contextmenu", "selectstart", "dragstart", "mousedown",
        "cut", "copy", "paste"
    ];

    // Clear inline event handlers
    eventsToClear.forEach(event => {
        document[`on${event}`] = null;
        document.body && (document.body[`on${event}`] = null);
    });

    // Prevent event blocking
    const stopEvents = (e) => {
        e.stopPropagation();
        e.stopImmediatePropagation();
    };

    // Add event listeners to prevent blocking
    eventsToClear.forEach(event => {
        // Capturing phase
        document.addEventListener(event, stopEvents, true);
        // Bubbling phase
        document.addEventListener(event, stopEvents, false);
    });

    // Override preventDefault for these events
    const originalPreventDefault = Event.prototype.preventDefault;
    Event.prototype.preventDefault = function() {
        if (eventsToClear.includes(this.type)) {
            return false;
        }
        return originalPreventDefault.apply(this, arguments);
    };

    // Function to apply styles to elements
    const applyStyles = () => {
        document.querySelectorAll('*').forEach(element => {
            if (window.getComputedStyle(element).userSelect === 'none') {
                element.style.setProperty('user-select', 'text', 'important');
            }
        });
    };

    // Apply styles and monitor for changes
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', applyStyles);
    } else {
        applyStyles();
    }

    // Monitor DOM changes
    new MutationObserver(applyStyles).observe(document.documentElement, {
        childList: true,
        subtree: true
    });
})();