document.addEventListener('DOMContentLoaded', async () => {
  // Get extension version and update display
  const version = chrome.runtime.getManifest().version;
  document.querySelector('.version').textContent = `v${version}`;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  if (!tab.url?.startsWith('http')) {
    document.querySelector('.controls').innerHTML = 
      '<div class="error">Quizripper only works on web pages</div>';
    return;
  }

  const hostname = new URL(tab.url).hostname;
  
  const {enabled = true, hosts = [], visibility = true, focus = true, copy = false, unblock = false} = 
    await chrome.storage.local.get({
      enabled: true,
      hosts: [],
      visibility: true,
      focus: true,
      copy: false,
      unblock: false
    });

  const siteToggle = document.getElementById('siteToggle');
  const visibilityToggle = document.getElementById('visibilityToggle');
  const focusToggle = document.getElementById('focusToggle');
  const copyToggle = document.getElementById('copyToggle');
  const unblockToggle = document.getElementById('unblockToggle');

  // Set initial states
  siteToggle.checked = enabled && hosts.includes(hostname);
  visibilityToggle.checked = visibility;
  focusToggle.checked = focus;
  copyToggle.checked = copy;
  unblockToggle.checked = unblock;

  // Site toggle handler
  siteToggle.addEventListener('change', async () => {
    let {hosts = []} = await chrome.storage.local.get({hosts: []});
    
    if (siteToggle.checked) {
      if (!hosts.includes(hostname)) {
        hosts.push(hostname);
        await chrome.storage.local.set({
          enabled: true,
          hosts: hosts
        });
      }
      chrome.action.setIcon({
        tabId: tab.id,
        path: {
          '16': '/data/icons/16.png',
          '32': '/data/icons/32.png',
          '48': '/data/icons/48.png'
        }
      });
    } else {
      hosts = hosts.filter(h => h !== hostname);
      await chrome.storage.local.set({hosts: hosts});
      
      chrome.action.setIcon({
        tabId: tab.id,
        path: {
          '16': '/data/icons/disabled/16.png',
          '32': '/data/icons/disabled/32.png',
          '48': '/data/icons/disabled/48.png'
        }
      });
    }
    
    await chrome.runtime.sendMessage({method: 'reactivate'});
    chrome.tabs.reload(tab.id);
  });

  // Event blocking toggles
  visibilityToggle.addEventListener('change', () => {
    chrome.storage.local.set({visibility: visibilityToggle.checked});
  });

  focusToggle.addEventListener('change', () => {
    chrome.storage.local.set({focus: focusToggle.checked});
  });

  // Copy toggle handler
  copyToggle.addEventListener('change', async () => {
    await chrome.storage.local.set({copy: copyToggle.checked});
    await chrome.runtime.sendMessage({method: 'reactivate'});
    chrome.tabs.reload(tab.id);
  });

  // Unblock toggle handler
  unblockToggle.addEventListener('change', async () => {
    await chrome.storage.local.set({unblock: unblockToggle.checked});
    await chrome.runtime.sendMessage({method: 'reactivate'});
    chrome.tabs.reload(tab.id);
  });
}); 